import axios from 'axios';

const updateMovie = async (movieId, movieData) => {
  try {
    const response = await axios.put(`https://yourapi.com/movies/${movieId}`, movieData, {
      headers: {
        'Content-Type': 'application/json',
        // Include any required authentication headers
      },
    });
    console.log('Movie updated successfully:', response.data);
  } catch (error) {
    console.error('Error updating movie:', error);
  }
};

// Example usage
const movieData = {
  title: 'New Movie Title',
  overview: 'Updated overview of the movie.',
  popularity: 8.7,
  releaseDate: '2024-10-29',
  voteAverage: 7.5,
  backdropPath: 'new_backdrop_path.jpg',
  posterPath: 'new_poster_path.jpg',
  isFeatured: 1,
};

updateMovie(1, movieData);  // Replace 1 with the actual movie ID
